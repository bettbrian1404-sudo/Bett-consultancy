# Bett Consultancy Website

A responsive, multi-page business website for **Bett Consultancy**, a Kenya-based web development and graphic design provider. Built from scratch with HTML5, CSS3, and vanilla JavaScript as a learning project — no frameworks, no templates.

## Live Demo
Homepage preview: https://claude.ai/artifact/X4YgmjuNwpgX2BFUE5UteL

## Technologies Used
- **HTML5** — semantic markup (`<header>`, `<nav>`, `<main>`, `<footer>`)
- **CSS3** — Flexbox, CSS Grid, custom properties (variables), media queries, transitions
- **JavaScript (vanilla)** — DOM manipulation, event listeners, form validation, portfolio filtering
- **Google Fonts** — Poppins (headings) + Inter (body)
- **Formspree** — form backend for contact submissions (no custom server required)

## Features
- 5 pages: Home, About, Services, Portfolio, Contact
- Fully responsive: distinct layouts for mobile, tablet, and desktop
- Mobile hamburger navigation with accessible `aria-expanded` state
- Live client-side form validation with inline error messages
- Filterable portfolio grid (by category, no page reload)
- SEO: unique titles/descriptions per page, Open Graph tags for social sharing
- Accessibility: skip-to-content link, `aria-current` for active nav state, labeled form fields, keyboard-navigable

## Skills Demonstrated
- Semantic, accessible HTML structure
- Responsive design with a mobile-first breakpoint strategy
- CSS custom properties for a maintainable design system
- DOM manipulation and event-driven JavaScript
- Form validation logic (including regex for email format)
- Working with third-party form backends (Formspree)
- Basic on-page SEO and Open Graph metadata
- Static site deployment workflow

## Project Structure
```
bett-consultancy/
├── index.html
├── about.html
├── services.html
├── portfolio.html
├── contact.html
├── css/style.css
├── js/script.js
└── images/
```

## Before Deploying
- [ ] Replace `action="https://formspree.io/f/YOUR_FORM_ID"` in `contact.html` with your real Formspree endpoint
- [ ] Replace `https://yourdomain.com/` in the Open Graph tags with your real domain
- [ ] Add a logo/preview image to `images/` and reference it in an `og:image` tag
- [ ] Replace placeholder social links (`#`) in `contact.html` with real profile URLs
- [ ] Replace sample portfolio items and testimonials with real client work as you take it on

## Deployment Checklist
- [ ] Functionality: all nav links, buttons, and the contact form work
- [ ] Responsiveness: tested at mobile (<768px), tablet (769–1024px), and desktop widths
- [ ] Accessibility: tab through the site with keyboard only, check color contrast
- [ ] SEO: unique title/description per page confirmed
- [ ] Performance: images compressed (once added), no unused CSS/JS
- [ ] No broken links (internal nav + footer)
- [ ] Test on Chrome, Firefox, and Safari (or at least two browsers)

## Deployment (GitHub Pages)
1. Create a GitHub repository and push this project to it
2. Go to **Settings → Pages**
3. Set source to your main branch, root folder
4. Your site publishes at `https://<username>.github.io/<repo-name>/`

**Domain vs. hosting vs. DNS, quickly:**
- **Hosting** = the server storing your files (GitHub Pages, Netlify, Vercel — all free for static sites like this one)
- **Domain** = the human-readable address (e.g. `bettconsultancy.com`) — bought separately from a registrar
- **DNS** = the system that points your domain to your hosting provider's servers

## Future Improvements
- Replace sample portfolio/testimonials with real client work
- Add a real logo and favicon
- Add a blog or case-studies section
- Move from Formspree to a custom Node.js/Express backend if the business scales
- Add a tablet-specific 2-column layout refinement beyond the current breakpoint
